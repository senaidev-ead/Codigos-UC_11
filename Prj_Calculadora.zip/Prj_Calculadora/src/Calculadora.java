/** * @author Rolfi Luz - Senai  *  */  
import java.util.Scanner;

public class Calculadora {

	public static void main(String args[]) {

		// Comando para ler o teclado
		Scanner leitura = new Scanner(System.in);

		System.out.println("Informe n�meros A");

		int a = leitura.nextInt();

		System.out.println("Informe n�meros B");

		int b = leitura.nextInt();

		Calculadora calc = new Calculadora();

		int resultado = calc.somar(a, b);

		System.out.println("Resultado:" + resultado);

	}

	public int somar(int A, int B) {
		return A + B;
	}

	public void imprimir() {
		System.out.println("Imprimir");
	}

}

