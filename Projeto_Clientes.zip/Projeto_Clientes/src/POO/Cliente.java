/** * @author Rolfi Luz - Senai  *  */
package POO;
//Representa��o da Classe ABSTRATA - Estere�tipo
// Classes Abstratas s�o classes gen�ricas 
abstract class Cliente {
	
		String nome;
		String email;

}

