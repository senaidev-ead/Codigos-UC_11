/** * @author Rolfi Luz - Senai  *  */
package POO;
public class ClientePF extends Cliente {
	
			String cpf;
}
