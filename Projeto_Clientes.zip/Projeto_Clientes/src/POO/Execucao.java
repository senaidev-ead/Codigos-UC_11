/** * @author Rolfi Luz - Senai  *  */  
package POO;
public class Execucao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClientePJ pj=new ClientePJ();
		ClientePF pf=new ClientePF();
		
		
		pj.nome="IES Senai";
		pj.email="senaiead@sp.senai.br";
		pj.cnpj="01.123.456.0001/01"; 
		
		
		pf.nome="Rolfi C Luz";
		pf.email="rolfi.luz@sp.senai.br";
		pf.cpf="123.456.789-10";
		
		System.out.println("================================");
		System.out.println("Cliente PF");
		System.out.println("Nome:"+pf.nome);
		System.out.println("Email:"+ pf.email);
		System.out.println("Cpf:"+ pf.cpf);
		
		System.out.println("================================");
		System.out.println("Cliente PJ");
		System.out.println("Nome:"+pj.nome);
		System.out.println("Email:"+ pj.email);
		System.out.println("Cnpj:"+ pj.cnpj);

	}

}

