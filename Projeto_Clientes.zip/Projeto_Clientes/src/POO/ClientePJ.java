/** * @author Rolfi Luz - Senai  *  */
package POO;
public class ClientePJ extends Cliente {
		String cnpj;

}
